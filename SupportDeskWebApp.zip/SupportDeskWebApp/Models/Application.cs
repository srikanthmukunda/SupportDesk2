﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SupportDeskWebApp.Models
{
    public class Application
    {
        public string Application1 { get; set; }
        public string Description { get; set; }
        public int ApplicationId { get; set; }
    }
}